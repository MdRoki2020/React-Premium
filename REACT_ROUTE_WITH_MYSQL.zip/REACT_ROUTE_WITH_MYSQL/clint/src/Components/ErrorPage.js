import React from 'react'

export default function ErrorPage() {
  return (
    <div>
      <h1>Error Page ! 404 NOT FOUND</h1>
    </div>
  )
}
