import 'bootstrap/dist/css/bootstrap.min.css';
import Navigationbar from './Components/Navigationbar';

function App() {
  return (
    <div className="">
      <Navigationbar />
    </div>
  );
}

export default App;
